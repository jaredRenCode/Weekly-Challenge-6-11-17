﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class anykeypressed : MonoBehaviour {

    public string scenetoload = "level1";
    public bool DoFade;
    


	void Update () {
        if (Input.anyKey)
        {
            Debug.Log("Exit Granted");
            
            if (DoFade)
            {
                AutoFade.LoadScene(scenetoload, 1, 1, Color.black);
            }else
            {
                SceneManager.LoadScene(scenetoload);
            }
        }
            
    }

}
