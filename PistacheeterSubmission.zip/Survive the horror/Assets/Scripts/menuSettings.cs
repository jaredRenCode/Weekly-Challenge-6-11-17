﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class menuSettings : MonoBehaviour {

    // Use this for initialization
    public void Settings () {
        SceneManager.LoadScene("Settings");
	}
	
	// Update is called once per frame
	public void MainMenu () {
        SceneManager.LoadScene("StartMenu");
	}
}
