﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class butonscript : MonoBehaviour {

    public SelectedScript closestbutton;
    public SelectedScript weakestbutton;
    public SelectedScript randombutton;
    public SelectedScript strongestbutton;

    public void boolbutton(string nameofbool)
    {
        if(nameofbool == "closest")
        {
            Bullet.weakest = false;
            Bullet.closest = true;
            Bullet.strongest = false;
            closestbutton.IsSelected = true;
            weakestbutton.IsSelected = false;
            randombutton.IsSelected = false;
            strongestbutton.IsSelected = false;
        }
        if (nameofbool == "weakest")
        {
            Bullet.closest = false;
            Bullet.weakest = true;
            Bullet.strongest = false;
            closestbutton.IsSelected = false;
            weakestbutton.IsSelected = true;
            randombutton.IsSelected = false;
            strongestbutton.IsSelected = false;
        }
        if (nameofbool == "strongest")
        {
            Bullet.closest = false;
            Bullet.weakest = false;
            closestbutton.IsSelected = false;
            weakestbutton.IsSelected = false;
            strongestbutton.IsSelected = true;
            randombutton.IsSelected = false;
        }
        if (nameofbool == "random")
        {
            Bullet.closest = false;
            Bullet.weakest = false;
            Bullet.strongest = false;
            strongestbutton.IsSelected = false;
            closestbutton.IsSelected = false;
            weakestbutton.IsSelected = false;
            randombutton.IsSelected = true;
        }
    }
}
