﻿using UnityEngine;

public class ExitButton : MonoBehaviour {

    public void quit()
    {
        Application.Quit();
    }

}
