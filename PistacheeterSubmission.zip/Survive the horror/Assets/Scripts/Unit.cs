﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour {

    public float health = 10f;
    public float speed = 2f;

    public int damage = 5;
    public int ScoreOnDestruction = 2;
    public int MoneyOnDestruction = 1;

    void Start()
    {
        transform.position = new Vector3(transform.position.x + Random.Range(-0.1f,0.1f), Random.Range(-3.38f, 2.91f));
    }

    void FixedUpdate()
    {
        transform.position = new Vector3(transform.position.x + speed, transform.position.y, transform.position.z);
        if (transform.position.x >= 3.54)
        {
            Destroy(gameObject);
            BaseScript.health -= damage;
        }
        if (health <= 0f)
        {
            Destroy(gameObject);
            ScoreScript.AddScore(1);
            BaseScript.money += MoneyOnDestruction;
        }
    }
}
