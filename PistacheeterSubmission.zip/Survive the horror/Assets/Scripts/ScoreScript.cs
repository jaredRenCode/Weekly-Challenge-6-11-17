﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScript : MonoBehaviour {

    public static int score;
    public static int lastHighScore;
    public Text text;

	// Use this for initialization
	void Start () {
        lastHighScore = PlayerPrefs.GetInt("score");
	}

    void Awake()
    {
        lastHighScore = PlayerPrefs.GetInt("score");
    }

    // Update is called once per frame
    void Update () {

        if(score > lastHighScore)
            PlayerPrefs.SetInt("score", score);

        

        text.text = "score: " + score.ToString();


    }

    public static void AddScore(int Ascore)
    {
        score += Ascore;
        PlayerPrefs.SetInt("realscore", score);
    }

}
