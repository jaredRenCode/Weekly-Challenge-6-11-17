﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectedScript : MonoBehaviour {

    public bool IsSelected;

	void FixedUpdate () {
        if (IsSelected)
        {
            Image img = this.gameObject.GetComponent<Image>();
            img.color = Color.gray;
        }
        if (!IsSelected)
        {
            Image img = this.gameObject.GetComponent<Image>();
            img.color = Color.white;
        }
    }
}
