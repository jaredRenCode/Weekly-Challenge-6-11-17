﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class BaseScript : MonoBehaviour {

    public static int health = 100;
    public static int money = 0;
    public Text healthText;
    public RectTransform healthBar;
    public float healthbardefaultsize;

    public static float TimePerMoney = 5;
    public static int MoneyEarned = 1;

    public float period = 0.0f;

    // Use this for initialization
    void Start () {
        healthbardefaultsize = healthBar.sizeDelta.x;
        healthbardefaultsize = healthbardefaultsize / 100;
        ScoreScript.score = 0;

    }
	
	// Update is called once per frame
	void Update () {
        if(health <= 0)
        {
            Die();
        }
        if(health >= 0) { 
            healthText.text = health.ToString();
        }


        if (period > TimePerMoney)
        {
            money += MoneyEarned;

            period = 0;
        }

        period += UnityEngine.Time.deltaTime;

        healthBar.sizeDelta = new Vector2(
          health * healthbardefaultsize,
          healthBar.sizeDelta.y);
    }

    void Die()
    {
        health = 100;
        money = 0;
        TimePerMoney = 5;
        MoneyEarned = 1;
        Bullet.speed = 4f;
        UpgradeButtonScript.bulletspeedM = 20;
        UpgradeButtonScript.firingspeedM = 30;
        
        turretscipt.TimePerBulletSpawnall = 1; ;
        SceneManager.LoadScene("death screen");
    }
}

