﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoneyText : MonoBehaviour {

    public Text Moneytext;
    int money;
    string moneyt;
	
	// Update is called once per frame
	void Update () {

        money = BaseScript.money;
        moneyt = money.ToString();

        Moneytext.text = "money: " + moneyt;

	}


}
