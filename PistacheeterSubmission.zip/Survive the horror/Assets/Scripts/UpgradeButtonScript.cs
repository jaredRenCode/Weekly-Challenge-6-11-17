﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeButtonScript : MonoBehaviour {

    [SerializeField]
    float amountlocal;

    [SerializeField]
    Text text;

    int upgradeamountfs;

    public static int amountofturrets;

    [SerializeField]
    float maxupgradesfs;

    public static int firingspeedM = 30;
    public static int bulletspeedM = 20;

    private void Update()
    {
        amountofturrets = GameObject.FindGameObjectsWithTag("Turret").Length;
    }

    

    public void UpgradeButton(string upgrade)
    {
        if(upgrade == "firingspeed" && upgradeamountfs < maxupgradesfs)
        {
            if (BaseScript.money >= (firingspeedM))
            {
                BaseScript.money -= (firingspeedM);
                firingspeedM += firingspeedM / 4;

                upgradeamountfs++;
                turretscipt.upgradeall("firingspeed", amountlocal);
                text.text = "(" + upgradeamountfs.ToString() + ")/" + maxupgradesfs + " firingspeed " + firingspeedM;
                
            }
            
            
        }


        if (upgrade == "bulletspeed" && upgradeamountfs < maxupgradesfs)
        {
            if (BaseScript.money >= (bulletspeedM))
            {
                BaseScript.money -= (bulletspeedM);
                bulletspeedM += bulletspeedM / 4;

                upgradeamountfs++;
                turretscipt.upgradeall("bulletspeed", amountlocal);
                text.text = "(" + upgradeamountfs.ToString() + ")/" + maxupgradesfs + " bulletspeed " + bulletspeedM;
            }

            
        }


    }
}
