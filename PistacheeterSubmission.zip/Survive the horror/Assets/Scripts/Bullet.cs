﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {

	public float damage = 1f;
	public Transform target;
	public static float speed = 4f;

    public static bool closest;
    public static bool weakest;
    public static bool strongest;

    public bool Damage = false;

    private GameObject[] units;

    private void Start()
    {
        units = GameObject.FindGameObjectsWithTag("Unit");

        if (units.Length <= 0)
            return;
        int index = units.Length;
        index = Random.Range(0, units.Length);
        target = units[index].transform;

        
        Unit targetUnit = target.gameObject.GetComponent<Unit>();
        FindTarget();

    }
    
    private void FindTarget()
    {
        
        units = GameObject.FindGameObjectsWithTag("Unit");

        if (units.Length <= 0)
            return;

        int index = units.Length;
        index = Random.Range(0, units.Length);
        target = units[index].transform;

        Unit targetUnit = target.gameObject.GetComponent<Unit>();

        if (closest)
        {
            target = GetClosestUnit(units);
        }

        if (weakest)
        {
            target = GetWeakestUnit(units);
            
        }
        if (strongest)
        {
            target = GetStrongestUnit(units);
            
        }
    }

    Transform GetClosestUnit(GameObject[] units)
    {
        Transform bestTarget = null;
        float closestDistanceSqr = Mathf.Infinity;
        Vector3 currentPosition = transform.position;
        foreach (GameObject potentialTarget in units)
        {
            Vector3 directionToTarget = potentialTarget.transform.position - currentPosition;
            float dSqrToTarget = directionToTarget.sqrMagnitude;
            if (dSqrToTarget < closestDistanceSqr)
            {
                closestDistanceSqr = dSqrToTarget;
                bestTarget = potentialTarget.transform;
            }
        }

        return bestTarget;
    }
    Transform GetWeakestUnit(GameObject[] units)
    {
        foreach (GameObject u in units)
        {
            Unit targetUnit = target.gameObject.GetComponent<Unit>();
            if (u.GetComponent<Unit>().health < targetUnit.health)
            {
                target = u.transform;
            }
        }
        return target;
    }
    Transform GetStrongestUnit(GameObject[] units)
    {
        foreach (GameObject u in units)
        {
            Unit targetUnit = target.gameObject.GetComponent<Unit>();
            if (u.GetComponent<Unit>().health > targetUnit.health)
            {
                target = u.transform;
            }
        }
        return target;
    }
    

    void Update () {
		if(target == null) {
            FindTarget();
            
            if (target == null)
            {
                Destroy(this.gameObject);
                return;
            }
            return;
        }

        if (weakest)
        {
            units = GameObject.FindGameObjectsWithTag("Unit");
            target = GetWeakestUnit(units);
        }

        if (strongest)
        {
            units = GameObject.FindGameObjectsWithTag("Unit");
            target = GetStrongestUnit(units);
        }

        Vector2 dir = target.position - this.transform.position;
        
        this.transform.up = target.position - this.transform.position;

        if (dir.magnitude <= 0.2f) {
			Unit en = target.gameObject.GetComponent<Unit>();
			if(en != null) {
				if(Damage) {
                    en.health -= damage;
				}
				else {
                    return;
				}
			}
            
			Destroy(gameObject);
		}
		else {
			this.transform.Translate( dir.normalized * speed * Time.deltaTime, Space.World );
		}
		
	}
	
}
