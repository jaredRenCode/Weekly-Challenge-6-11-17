﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class turretscipt : MonoBehaviour {


    public GameObject bullet;

    public float period = 0.0f;
    public static float TimePerBulletSpawnall = 1.1f;
    float TimePerBulletSpawn = 1;
    float TimePerBulletSpawnused;

    bool uselocal;

    

    void Update()
    {
        
        TimePerBulletSpawnused = (TimePerBulletSpawn + TimePerBulletSpawnall) / 2;

        if (period > TimePerBulletSpawnall)
        {

            Instantiate(bullet, this.transform.position, Quaternion.Euler(0,0,0));

            period = 0;
        }
        period += UnityEngine.Time.deltaTime;
    }

    public static void upgradeall(string update, float amount)
    {
        if(update == "firingspeed")
        {

            turretscipt.TimePerBulletSpawnall -= amount;
        }
        if (update == "bulletspeed")
        {
            Bullet.speed += amount;
        }
    }

    

}
