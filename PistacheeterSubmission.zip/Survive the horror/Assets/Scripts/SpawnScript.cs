﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnScript : MonoBehaviour {
    

    public float TimePerAllUnitSpawn = 1;

    public GameObject zombG;
    public GameObject tankG;
    public GameObject jetsG;

    public float period = 0.0f;
    public float period2 = 0.0f;

    public int totime;
    public int totimem;

    public bool tanksB = false;
    public bool zombB = true;
    public bool jetsB = false;

    public float tanksF = 0;
    public float zombF = 0;
    public float jetsF = 0;

    public float tanksS = 0.37f;
    public float jetsS = 0.65f;

    void FixedUpdate () {
        
        if (period > TimePerAllUnitSpawn)
        {
            if (zombB)
                zombF += 1;

            if (zombF >= 1) { 
                zombF = 0;
                Instantiate(zombG);
            }

            if (tanksB)
                tanksF += tanksS;

            if ( tanksF >= 2)
            {
                Instantiate(tankG);
                tanksF = 0;
            }

            if (jetsB)
                jetsF += jetsS;

            if (jetsF >= 1.96)
            {
                Instantiate(jetsG);
                jetsF = 0;
            }

            period = 0;
        }

        if (period2 > 1)
        {
            if (totime == 15 && TimePerAllUnitSpawn >= 0.22)
            {
                TimePerAllUnitSpawn -= TimePerAllUnitSpawn / 20;
                if (TimePerAllUnitSpawn <= 0.73)
                    tanksB = true;
                if (TimePerAllUnitSpawn <= 0.84)
                    jetsB = true;
                totime = 0;
            }

            

            totime++;

            period2 = 0;
        }

        period2 += UnityEngine.Time.deltaTime;
        period += UnityEngine.Time.deltaTime;

        
        

	}
}
