﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButton : MonoBehaviour {


    public void StartScene(string scene)
    {
        SceneManager.LoadScene(scene);
    }

    

}
